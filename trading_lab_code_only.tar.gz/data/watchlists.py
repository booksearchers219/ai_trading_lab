def load_watchlist(filename="watchlist.txt"):
    tickers = []

    try:
        with open(filename, "r") as f:
            for line in f:
                t = line.strip().upper()
                if t:
                    tickers.append(t)
    except FileNotFoundError:
        print("watchlist.txt not found")
        return []

    return tickers


TOP10 = [
    "AAPL",
    "MSFT",
    "NVDA",
    "GOOGL",
    "AMZN",
    "META",
    "TSLA",
    "AVGO",
    "AMD",
    "NFLX"
]

DISCOVERY_UNIVERSE = [
    "NVDA", "AMD", "AVGO", "TSLA", "META", "AAPL", "MSFT",
    "GOOGL", "AMZN", "NFLX", "SMCI", "ARM", "INTC",
    "MU", "QCOM", "ADBE", "CRM", "ORCL", "NOW", "SHOP"
]


def load_crypto_watchlist(filename="crypto_watchlist.txt"):
    tickers = []

    try:
        with open(filename, "r") as f:
            for line in f:
                t = line.strip().upper()
                if t:
                    tickers.append(t)

    except FileNotFoundError:
        print("crypto_watchlist.txt not found")
        return []

    return tickers


def get_live_price(ticker):
    try:
        data = yf.Ticker(ticker)

        hist = data.history(period="5d", interval="5m")

        if hist.empty:
            return None

        price = hist["Close"].iloc[-1]

        if price <= 0:
            return None

        return float(price)

    except Exception:
        return None


